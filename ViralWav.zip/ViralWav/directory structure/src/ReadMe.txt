Requires Windows and Unity Player

Click on the executable to run the game.  Please include the data folder.