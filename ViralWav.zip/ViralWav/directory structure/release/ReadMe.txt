Requires Windows and Unity Player

Click on the executable to run the game.  Include the data folder.